package com.qhub.quizapp.student

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qhub.quizapp.data.Quiz
import com.qhub.quizapp.data.Question
import com.qhub.quizapp.data.SemesterRepository

@Composable
fun StudentDashboard() {

    var currentScreen by remember { mutableStateOf("dashboard") }

    // Left-side navigation drawer
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var isQuizMenuExpanded by remember { mutableStateOf(true) }
    val dashboardScrollState = rememberScrollState()

    var submittedAnswers by remember {
        mutableStateOf<List<Int>>(emptyList())
    }

    var selectedArchivedSemester by remember {
        mutableStateOf<Int?>(null)
    }

    // Quiz category selection
    var selectedQuizCategory by remember {
        mutableStateOf("Available")
    }

    // Tracks whether the sample quiz has been submitted
    var isSampleQuizCompleted by remember {
        mutableStateOf(false)
    }

    val sampleQuiz = remember {
        Quiz(
            quizId = "quiz1",
            title = "Programming Fundamentals",
            durationMinutes = 15,
            shuffleOptions = false,
            questions = listOf(
                Question(
                    "Which language is used for Android development?",
                    listOf("Python", "Kotlin", "C", "HTML"),
                    1
                ),
                Question(
                    "What does CPU stand for?",
                    listOf(
                        "Central Processing Unit",
                        "Computer Personal Unit",
                        "Central Program Utility",
                        "Control Processing Unit"
                    ),
                    0
                )
            )
        )
    }

    when (currentScreen) {

        // Archived semester screen
        "archive" -> {

            val archivedSemester = SemesterRepository
                .getArchivedSemesters()
                .find {
                    it.semesterNumber == selectedArchivedSemester
                }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF5F7FA))
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {

                Text(
                    text = "Archived Semester",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF263B53)
                )

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Semester ${archivedSemester?.semesterNumber ?: "-"}",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF263B53)
                )

                Spacer(modifier = Modifier.height(15.dp))

                Text(
                    text = "Previous Subjects",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF263B53)
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (archivedSemester != null) {

                    archivedSemester.subjects.forEach { subject ->

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = subject.subjectName,
                                modifier = Modifier.padding(16.dp),
                                fontSize = 16.sp,
                                color = Color(0xFF263B53)
                            )
                        }
                    }

                } else {

                    Text(
                        text = "Archived semester not found.",
                        color = Color.Gray
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        currentScreen = "dashboard"
                        selectedArchivedSemester = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Back to Dashboard")
                }
            }
        }

        // Instructions screen
        "instructions" -> QuizInstructions(
            quiz = sampleQuiz,
            onStartQuiz = {
                currentScreen = "quiz"
            }
        )

        // Quiz screen
        "quiz" -> QuizScreen(
            quiz = sampleQuiz,
            onSubmit = { answers ->
                submittedAnswers = answers
                isSampleQuizCompleted = true
                selectedQuizCategory = "Completed"
                currentScreen = "results"
            }
        )

        // Results screen
        "results" -> QuizResultScreen(
            quiz = sampleQuiz,
            answers = submittedAnswers,
            onBackToDashboard = {
                currentScreen = "dashboard"
                selectedQuizCategory = "Completed"
            }
        )

        // Student dashboard
        else -> {

            val blue = Color(0xFF527DAA)
            val background = Color(0xFFF5F7FA)

            val activeSemester =
                SemesterRepository.getActiveSemester()

            val archivedSemesters =
                SemesterRepository.getArchivedSemesters()

            val availableCount =
                if (isSampleQuizCompleted) 0 else 1

            val upcomingCount = 2

            val completedCount =
                if (isSampleQuizCompleted) 1 else 0

            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        modifier = Modifier.fillMaxHeight(),
                        drawerContainerColor = Color.White
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {

                            Text(
                                text = "Menu",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF263B53),
                                modifier = Modifier.padding(vertical = 12.dp)
                            )

                            Divider()

                            // Main Quiz menu
                            NavigationDrawerItem(
                                label = {
                                    Text(
                                        text = "Quiz",
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                selected = false,
                                onClick = {
                                    isQuizMenuExpanded = !isQuizMenuExpanded
                                }
                            )

                            // Quiz submenu
                            if (isQuizMenuExpanded) {

                                NavigationDrawerItem(
                                    label = { Text("Available") },
                                    selected = selectedQuizCategory == "Available",
                                    onClick = {
                                        selectedQuizCategory = "Available"

                                        scope.launch {
                                            drawerState.close()
                                            dashboardScrollState.animateScrollTo(
                                                dashboardScrollState.maxValue
                                            )
                                        }
                                    },
                                    modifier = Modifier.padding(start = 18.dp)
                                )

                                NavigationDrawerItem(
                                    label = { Text("Upcoming") },
                                    selected = selectedQuizCategory == "Upcoming",
                                    onClick = {
                                        selectedQuizCategory = "Upcoming"

                                        scope.launch {
                                            drawerState.close()
                                            dashboardScrollState.animateScrollTo(
                                                dashboardScrollState.maxValue
                                            )
                                        }
                                    },
                                    modifier = Modifier.padding(start = 18.dp)
                                )

                                NavigationDrawerItem(
                                    label = { Text("Completed") },
                                    selected = selectedQuizCategory == "Completed",
                                    onClick = {
                                        selectedQuizCategory = "Completed"

                                        scope.launch {
                                            drawerState.close()
                                            dashboardScrollState.animateScrollTo(
                                                dashboardScrollState.maxValue
                                            )
                                        }
                                    },
                                    modifier = Modifier.padding(start = 18.dp)
                                )
                            }
                        }
                    }
                }
            ) {

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(background)
                        .padding(20.dp)
                        .verticalScroll(dashboardScrollState)
                ) {

                    // Top bar with hamburger menu
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {

                        Text(
                            text = "☰",
                            fontSize = 30.sp,
                            color = Color(0xFF263B53),
                            modifier = Modifier.clickable {
                                scope.launch {
                                    drawerState.open()
                                }
                            }
                        )

                        Spacer(modifier = Modifier.width(16.dp))

                        Text(
                            text = "QHub",
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF263B53)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = "Hello, Student!",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF263B53)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Ready to test your knowledge?",
                        fontSize = 15.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Current semester
                    Text(
                        text = "My Academics",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF263B53)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ) {

                        Column(
                            modifier = Modifier.padding(18.dp)
                        ) {

                            Text(
                                text = "CURRENT SEMESTER",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = blue
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Semester ${activeSemester?.semesterNumber ?: "-"}",
                                fontSize = 23.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF263B53)
                            )

                            Spacer(modifier = Modifier.height(15.dp))

                            Text(
                                text = "Your Subjects",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF263B53)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            if (activeSemester != null &&
                                activeSemester.subjects.isNotEmpty()
                            ) {

                                activeSemester.subjects.forEach { subject ->

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 9.dp)
                                    ) {

                                        Text(
                                            text = "•",
                                            color = blue,
                                            fontSize = 18.sp
                                        )

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Text(
                                            text = subject.subjectName,
                                            fontSize = 15.sp,
                                            color = Color(0xFF263B53)
                                        )
                                    }
                                }

                            } else {

                                Text(
                                    text = "No subjects assigned yet.",
                                    color = Color.Gray,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(22.dp))

                    // Archived semesters
                    Text(
                        text = "Archived Semesters",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF263B53)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (archivedSemesters.isEmpty()) {

                        Text(
                            text = "No previous semesters yet.",
                            fontSize = 14.sp,
                            color = Color.Gray
                        )

                    } else {

                        archivedSemesters.forEach { semester ->

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 10.dp)
                                    .clickable {
                                        selectedArchivedSemester =
                                            semester.semesterNumber

                                        currentScreen = "archive"
                                    },
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = Color.White
                                )
                            ) {

                                Column(
                                    modifier = Modifier.padding(16.dp)
                                ) {

                                    Text(
                                        text = "Semester ${semester.semesterNumber}",
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF263B53)
                                    )

                                    Text(
                                        text = "${semester.subjects.size} subjects • Archived",
                                        fontSize = 13.sp,
                                        color = Color.Gray
                                    )

                                    Spacer(modifier = Modifier.height(5.dp))

                                    Text(
                                        text = "Tap to view subjects",
                                        fontSize = 12.sp,
                                        color = blue
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(22.dp))

                    // Learning journey
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = blue
                        ),
                        shape = RoundedCornerShape(18.dp)
                    ) {

                        Column(
                            modifier = Modifier.padding(20.dp)
                        ) {

                            Text(
                                text = "Your Learning Journey",
                                color = Color.White,
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Practice quizzes and improve your skills!",
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(25.dp))

                    // Quiz categories
                    Text(
                        text = "My Quizzes",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF263B53)
                    )

                    Spacer(modifier = Modifier.height(15.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {

                        QuizCategoryTab(
                            title = "Available",
                            count = availableCount,
                            selected = selectedQuizCategory == "Available",
                            modifier = Modifier.weight(1f),
                            onClick = {
                                selectedQuizCategory = "Available"
                            }
                        )

                        QuizCategoryTab(
                            title = "Upcoming",
                            count = upcomingCount,
                            selected = selectedQuizCategory == "Upcoming",
                            modifier = Modifier.weight(1f),
                            onClick = {
                                selectedQuizCategory = "Upcoming"
                            }
                        )

                        QuizCategoryTab(
                            title = "Completed",
                            count = completedCount,
                            selected = selectedQuizCategory == "Completed",
                            modifier = Modifier.weight(1f),
                            onClick = {
                                selectedQuizCategory = "Completed"
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Available quizzes
                    if (selectedQuizCategory == "Available") {

                        if (!isSampleQuizCompleted) {

                            QuizCard(
                                title = "Programming Fundamentals",
                                details = "Sample Quiz • 2 Questions • 15 Minutes",
                                onClick = {
                                    currentScreen = "instructions"
                                }
                            )

                        } else {

                            EmptyQuizMessage(
                                message = "No available quizzes right now."
                            )
                        }
                    }

                    // Upcoming quizzes
                    else if (selectedQuizCategory == "Upcoming") {

                        QuizCard(
                            title = "Database Management",
                            details = "Scheduled soon • Not available yet",
                            enabled = false
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        QuizCard(
                            title = "Computer Networks",
                            details = "Scheduled soon • Not available yet",
                            enabled = false
                        )
                    }

                    // Completed quizzes
                    else if (selectedQuizCategory == "Completed") {

                        if (isSampleQuizCompleted) {

                            QuizCard(
                                title = "Programming Fundamentals",
                                details = "Submitted • View Result",
                                onClick = {
                                    currentScreen = "results"
                                }
                            )

                        } else {

                            EmptyQuizMessage(
                                message = "You haven't completed any quizzes yet."
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

// Quiz category tab
@Composable
fun QuizCategoryTab(
    title: String,
    count: Int,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {

    val selectedColor = Color(0xFF527DAA)

    Card(
        modifier = modifier.clickable {
            onClick()
        },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) {
                selectedColor
            } else {
                Color.White
            }
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 2.dp
        )
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
        ) {

            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (selected) Color.White else Color(0xFF263B53),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = count.toString(),
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = if (selected) Color.White else Color(0xFF527DAA)
            )
        }
    }
}

// Empty category message
@Composable
fun EmptyQuizMessage(message: String) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        )
    ) {

        Text(
            text = message,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            fontSize = 14.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )
    }
}

// Reusable quiz card
@Composable
fun QuizCard(
    title: String,
    details: String,
    onClick: () -> Unit = {},
    enabled: Boolean = true
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (enabled) {
                    Modifier.clickable {
                        onClick()
                    }
                } else {
                    Modifier
                }
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 2.dp
        )
    ) {

        Column(
            modifier = Modifier.padding(18.dp)
        ) {

            Text(
                text = title,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF263B53)
            )

            Spacer(modifier = Modifier.height(7.dp))

            Text(
                text = details,
                fontSize = 13.sp,
                color = Color.Gray
            )
        }
    }
}